def fourthPower(x):
    '''
    x: int or float.
    '''
    # Your code here
    return square(square(x))
