# Coding exercises and Problem Sets for MITx: 6.00.1x Introduction to Computer Science and Programming Using Python, edX, Feb 2018

All code in this course uses Python 3.x.
