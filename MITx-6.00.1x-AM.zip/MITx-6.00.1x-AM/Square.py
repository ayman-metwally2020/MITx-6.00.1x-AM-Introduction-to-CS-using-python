def square(x):
    '''
    x: int or float.
    '''
    # Your code here
    
    return x*x
